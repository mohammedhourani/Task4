
numbers = []

for i in range(5):

  number = int(input("Enter a number: "))

  numbers.append(number)


print("Max:", max(numbers))
print("Min:", min(numbers))
